package com.example.to_do_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
